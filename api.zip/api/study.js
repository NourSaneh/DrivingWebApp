import { connectDB } from "./models/_db";
import StudyProgress from "../models/StudyProgress";

const FIXED_ID = "studyguide";

export default async function handler(req, res) {
  await connectDB();

  if (req.method === "GET") {
    const record =
      (await StudyProgress.findOne({ userId: FIXED_ID })) || {
        userId: FIXED_ID,
        completedTopics: [],
      };

    return res.status(200).json(record);
  }

  return res.status(405).json({ message: "Method not allowed" });
}
